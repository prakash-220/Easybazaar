from unicodedata import category
from django.contrib import admin
from .models import *

admin.site.register(Catagory)
admin.site.register(Product)

